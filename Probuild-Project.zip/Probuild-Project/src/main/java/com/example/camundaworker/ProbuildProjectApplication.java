package com.example.camundaworker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProbuildProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProbuildProjectApplication.class, args);
    }

}

package com.example.camundaworker;

import io.camunda.client.CamundaClient;
import io.camunda.client.annotation.JobWorker;
import io.camunda.client.api.response.ActivatedJob;
import io.camunda.client.api.worker.JobClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ProcessNameWorker {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessNameWorker.class);
    private static final Duration MESSAGE_TTL = Duration.ofSeconds(60);

    private final CamundaClient camundaClient;

    public ProcessNameWorker(CamundaClient camundaClient) {
        this.camundaClient = camundaClient;
    }

    // ─────────────────────────────────────────────────────────────────
    // TOOL PRICING CATALOGUE
    // ─────────────────────────────────────────────────────────────────

    private static final Map<String, Double> TOOL_PURCHASE_PRICES = Map.of(
            "timber",       45.00,
            "insulation",   30.00,
            "plasterboard", 25.00
    );

    private static final Map<String, Double> TOOL_HIRE_PRICES = Map.of(
            "timber",       8.00,
            "insulation",   6.00,
            "plasterboard", 5.00
    );

    private static final Map<String, Double> TOOL_DEPOSITS = Map.of(
            "timber",       20.00,
            "insulation",   15.00,
            "plasterboard", 10.00
    );

    // ─────────────────────────────────────────────────────────────────
    // HELPER METHODS
    // ─────────────────────────────────────────────────────────────────

    private String getVar(Map<String, Object> vars, String key, String fallback) {
        Object val = vars.get(key);
        if (val == null) {
            LOGGER.warn("Variable '{}' not found, using fallback: {}", key, fallback);
            return fallback;
        }
        return val.toString();
    }

    private double round2(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    private LocalDate parseDate(String dateStr) {
        try {
            return LocalDate.parse(dateStr.split("T")[0], DateTimeFormatter.ISO_LOCAL_DATE);
        } catch (Exception e) {
            LOGGER.error("Failed to parse date: {}", dateStr);
            return LocalDate.now();
        }
    }

    @SuppressWarnings("unchecked")
    private List<String> getSelectedTools(Map<String, Object> vars) {
        Object tools = vars.get("selectedTools");
        if (tools == null) return List.of();
        if (tools instanceof List) return (List<String>) tools;
        String toolStr = tools.toString().replaceAll("[\\[\\]\"]", "");
        if (toolStr.isBlank()) return List.of();
        return List.of(toolStr.split(",\\s*"));
    }

    private void publishToStartEvent(String messageName, Map<String, Object> variables) {
        LOGGER.info("Publishing '{}' to start event", messageName);
        camundaClient.newPublishMessageCommand()
                .messageName(messageName)
                .correlationKey("")
                .timeToLive(MESSAGE_TTL)
                .variables(variables)
                .send().join();
    }

    private void publishToCatchEvent(String messageName, String correlationKey, Map<String, Object> variables) {
        LOGGER.info("Publishing '{}' with correlationKey={}", messageName, correlationKey);
        camundaClient.newPublishMessageCommand()
                .messageName(messageName)
                .correlationKey(correlationKey)
                .timeToLive(MESSAGE_TTL)
                .variables(variables)
                .send().join();
    }

    // ─────────────────────────────────────────────────────────────────
    // CUSTOMER POOL
    // ─────────────────────────────────────────────────────────────────

    @JobWorker(type = "checkOnlineAvailability")
    public void checkOnlineAvailability(final ActivatedJob job, final JobClient client) {
        LOGGER.info("checkOnlineAvailability triggered");
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("onlineAvailable", true))
                .send().join();
    }

    @JobWorker(type = "calculatePrice")
    public void calculatePrice(final ActivatedJob job, final JobClient client) {
        LOGGER.info("calculatePrice triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        int quantity = Integer.parseInt(getVar(vars, "quantity", "1"));
        List<String> selectedTools = getSelectedTools(vars);

        double totalPrice = 0.0;
        StringBuilder priceBreakdown = new StringBuilder();

        if (selectedTools.isEmpty()) {
            totalPrice = quantity * 49.99;
            priceBreakdown.append("Default item x").append(quantity).append(" = £").append(totalPrice);
        } else {
            for (String tool : selectedTools) {
                String toolKey = tool.trim().toLowerCase();
                double unitPrice = TOOL_PURCHASE_PRICES.getOrDefault(toolKey, 49.99);
                double lineTotal = unitPrice * quantity;
                totalPrice += lineTotal;
                priceBreakdown.append(tool).append(" x").append(quantity)
                        .append(" @ £").append(unitPrice).append(" = £").append(round2(lineTotal)).append(" | ");
            }
        }

        totalPrice = round2(totalPrice);
        LOGGER.info("Price breakdown: {} | Total: £{}", priceBreakdown, totalPrice);

        client.newCompleteCommand(job.getKey())
                .variables(Map.of(
                        "totalAmount", totalPrice,
                        "priceBreakdown", priceBreakdown.toString()
                ))
                .send().join();
    }

    @JobWorker(type = "registerMember")
    public void registerMember(final ActivatedJob job, final JobClient client) {
        LOGGER.info("registerMember triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String name = getVar(vars, "customerFirstName", "Customer") + " "
                + getVar(vars, "customerLastName", "");
        String tradeCardNumber = "TC-" + System.currentTimeMillis();
        LOGGER.info("Registering member: {} | tradeCard: {}", name.trim(), tradeCardNumber);
        client.newCompleteCommand(job.getKey())
                .variables(Map.of(
                        "membershipRegistered", true,
                        "tradeCardNumber", tradeCardNumber
                ))
                .send().join();
    }

    @JobWorker(type = "processPayment")
    public void processPayment(final ActivatedJob job, final JobClient client) {
        LOGGER.info("processPayment triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        double totalAmount = Double.parseDouble(getVar(vars, "totalAmount", "0"));
        String paymentMethod = getVar(vars, "paymentMethod", "card");
        LOGGER.info("Processing payment of £{} via {}", totalAmount, paymentMethod);
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("paymentSuccessful", true))
                .send().join();
    }

    @JobWorker(type = "sendCreditApplication")
    public void sendCreditApplication(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendCreditApplication triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String customerProcessKey = String.valueOf(job.getProcessInstanceKey());
        vars.put("customerProcessKey", customerProcessKey);
        publishToStartEvent("creditApplication", vars);
        LOGGER.info("Credit application sent | customerProcessKey={}", customerProcessKey);
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("customerProcessKey", customerProcessKey))
                .send().join();
    }

    @JobWorker(type = "sendPurchaseDetail")
    public void sendPurchaseDetail(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendPurchaseDetail triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String customerProcessKey = String.valueOf(job.getProcessInstanceKey());
        vars.put("customerProcessKey", customerProcessKey);
        publishToStartEvent("purchaseDetail", vars);
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("customerProcessKey", customerProcessKey))
                .send().join();
    }

    @JobWorker(type = "sendDeliveryRequirements")
    public void sendDeliveryRequirements(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendDeliveryRequirements triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String customerProcessKey = String.valueOf(job.getProcessInstanceKey());
        vars.put("customerProcessKey", customerProcessKey);
        publishToStartEvent("toolRequest", vars);
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("customerProcessKey", customerProcessKey))
                .send().join();
    }

    @JobWorker(type = "sendHireRequest")
    public void sendHireRequest(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendHireRequest triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String customerProcessKey = String.valueOf(job.getProcessInstanceKey());
        vars.put("customerProcessKey", customerProcessKey);
        publishToStartEvent("hireRequest", vars);
        LOGGER.info("Hire request sent | customerProcessKey={}", customerProcessKey);
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("customerProcessKey", customerProcessKey))
                .send().join();
    }

    // ─────────────────────────────────────────────────────────────────
    // FINTRUST UK POOL
    // ─────────────────────────────────────────────────────────────────

    @JobWorker(type = "processCreditApplication")
    public void processCreditApplication(final ActivatedJob job, final JobClient client) {
        LOGGER.info("processCreditApplication triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        double amount = Double.parseDouble(getVar(vars, "totalAmount", "500"));
        boolean approved = amount < 5000;
        LOGGER.info("Credit application | amount=£{} | approved={}", amount, approved);
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("creditApproved", approved))
                .send().join();
    }

    @JobWorker(type = "logApproved")
    public void logApproved(final ActivatedJob job, final JobClient client) {
        LOGGER.info("logApproved: credit application approved");
        client.newCompleteCommand(job.getKey()).send().join();
    }

    @JobWorker(type = "logDeclined")
    public void logDeclined(final ActivatedJob job, final JobClient client) {
        LOGGER.info("logDeclined: credit application declined");
        client.newCompleteCommand(job.getKey()).send().join();
    }

    @JobWorker(type = "sendRepaymentPlan")
    public void sendRepaymentPlan(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendRepaymentPlan triggered");
        client.newCompleteCommand(job.getKey()).send().join();
    }

    @JobWorker(type = "sendFinanceDecision")
    public void sendFinanceDecision(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendFinanceDecision triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        boolean approved = Boolean.parseBoolean(getVar(vars, "creditApproved", "false"));
        String customerProcessKey = getVar(vars, "customerProcessKey", "NOT_FOUND");
        publishToCatchEvent("financeDecision", customerProcessKey, Map.of("creditApproved", approved));
        LOGGER.info("Finance decision sent | approved={} | customerProcessKey={}", approved, customerProcessKey);
        client.newCompleteCommand(job.getKey()).send().join();
    }

    // ─────────────────────────────────────────────────────────────────
    // PROBUILD LTD POOL — TOOL HIRE TEAM
    // ─────────────────────────────────────────────────────────────────

    @JobWorker(type = "checkToolAvailability")
    public void checkToolAvailability(final ActivatedJob job, final JobClient client) {
        LOGGER.info("checkToolAvailability triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        List<String> selectedTools = getSelectedTools(vars);
        LOGGER.info("Checking availability for tools: {}", selectedTools);
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("toolAvailable", true))
                .send().join();
    }

    @JobWorker(type = "confirmHireBooking")
    public void confirmHireBooking(final ActivatedJob job, final JobClient client) {
        LOGGER.info("confirmHireBooking triggered");
        Map<String, Object> vars = job.getVariablesAsMap();

        // Parse hire dates and calculate duration
        String startDateStr = getVar(vars, "hireStartDate", "");
        String endDateStr = getVar(vars, "hireEndDate", "");
        int hireDuration = 1;
        if (!startDateStr.isEmpty() && !endDateStr.isEmpty()) {
            LocalDate startDate = parseDate(startDateStr);
            LocalDate endDate = parseDate(endDateStr);
            hireDuration = (int) ChronoUnit.DAYS.between(startDate, endDate);
            if (hireDuration < 1) hireDuration = 1;
        }
        LOGGER.info("Hire duration: {} days", hireDuration);

        // Calculate hire cost and deposit per tool
        List<String> selectedTools = getSelectedTools(vars);
        double totalHireCost = 0.0;
        double totalDeposit = 0.0;
        StringBuilder hireBreakdown = new StringBuilder();

        if (selectedTools.isEmpty()) {
            totalHireCost = hireDuration * 15.00;
            totalDeposit = 50.00;
            hireBreakdown.append("Default tool x").append(hireDuration).append(" days");
        } else {
            for (String tool : selectedTools) {
                String toolKey = tool.trim().toLowerCase();
                double dailyRate = TOOL_HIRE_PRICES.getOrDefault(toolKey, 15.00);
                double deposit = TOOL_DEPOSITS.getOrDefault(toolKey, 50.00);
                double lineCost = dailyRate * hireDuration;
                totalHireCost += lineCost;
                totalDeposit += deposit;
                hireBreakdown.append(tool)
                        .append(" @ £").append(dailyRate).append("/day x ")
                        .append(hireDuration).append(" days = £").append(round2(lineCost))
                        .append(" | Deposit: £").append(deposit).append(" | ");
            }
        }

        totalHireCost = round2(totalHireCost);
        totalDeposit = round2(totalDeposit);
        double totalAmount = round2(totalHireCost + totalDeposit);
        String bookingReference = "BK-" + System.currentTimeMillis();

        LOGGER.info("Total hire cost: £{} | Deposit: £{} | Total: £{} | Duration: {} days | Ref: {}",
                totalHireCost, totalDeposit, totalAmount, hireDuration, bookingReference);

        client.newCompleteCommand(job.getKey())
                .variables(Map.of(
                        "bookingReference", bookingReference,
                        "hireDuration", hireDuration,
                        "totalHireCost", totalHireCost,
                        "depositAmount", totalDeposit,
                        "totalAmount", totalAmount,
                        "hireBreakdown", hireBreakdown.toString()
                ))
                .send().join();
    }

    // Sends ALL variables back to Customer so the hire summary form can display them
    @JobWorker(type = "sendBookingConfirmed")
    public void sendBookingConfirmed(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendBookingConfirmed triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String customerProcessKey = getVar(vars, "customerProcessKey", "NOT_FOUND");
        String bookingReference = getVar(vars, "bookingReference", "BK-UNKNOWN");

        Map<String, Object> payload = new HashMap<>();
        payload.put("bookingReference", bookingReference);
        payload.put("hireDuration", vars.getOrDefault("hireDuration", 1));
        payload.put("totalHireCost", vars.getOrDefault("totalHireCost", 0));
        payload.put("depositAmount", vars.getOrDefault("depositAmount", 0));
        payload.put("totalAmount", vars.getOrDefault("totalAmount", 0));
        payload.put("hireBreakdown", vars.getOrDefault("hireBreakdown", ""));
        payload.put("selectedTools", vars.getOrDefault("selectedTools", ""));
        payload.put("quantity", vars.getOrDefault("quantity", 0));
        payload.put("hireStartDate", vars.getOrDefault("hireStartDate", ""));
        payload.put("hireEndDate", vars.getOrDefault("hireEndDate", ""));
        payload.put("toolAvailable", true);

        publishToCatchEvent("hireConfirmed", customerProcessKey, payload);
        LOGGER.info("Booking confirmed sent | ref={} | customerProcessKey={}", bookingReference, customerProcessKey);
        client.newCompleteCommand(job.getKey()).send().join();
    }

    @JobWorker(type = "sendToolUnavailable")
    public void sendToolUnavailable(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendToolUnavailable triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String customerProcessKey = getVar(vars, "customerProcessKey", "NOT_FOUND");
        publishToCatchEvent("toolUnavailable", customerProcessKey, Map.of("toolAvailable", false));
        LOGGER.info("Tool unavailable sent | customerProcessKey={}", customerProcessKey);
        client.newCompleteCommand(job.getKey()).send().join();
    }

    // ─────────────────────────────────────────────────────────────────
    // PROBUILD LTD POOL — LOGISTICS TEAM
    // ─────────────────────────────────────────────────────────────────

    @JobWorker(type = "notifyCustomer")
    public void notifyCustomer(final ActivatedJob job, final JobClient client) {
        LOGGER.info("notifyCustomer triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String customerProcessKey = getVar(vars, "customerProcessKey", "NOT_FOUND");
        String deliveryStatus = getVar(vars, "deliveryStatus", "Delivered");
        String actualDeliveryDate = getVar(vars, "actualDeliveryDate", "");
        publishToCatchEvent("packageDelivered", customerProcessKey, Map.of(
                "deliveryStatus", deliveryStatus,
                "actualDeliveryDate", actualDeliveryDate
        ));
        LOGGER.info("Customer notified | status={} | customerProcessKey={}", deliveryStatus, customerProcessKey);
        client.newCompleteCommand(job.getKey()).send().join();
    }

    // ─────────────────────────────────────────────────────────────────
    // PROBUILD LTD POOL — WAREHOUSE TEAM
    // ─────────────────────────────────────────────────────────────────

    @JobWorker(type = "markToolAvailable")
    public void markToolAvailable(final ActivatedJob job, final JobClient client) {
        LOGGER.info("markToolAvailable triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        LOGGER.info("Tool {} marked as available", getVar(vars, "toolId", "unknown"));
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("toolStatus", "available"))
                .send().join();
    }

    @JobWorker(type = "sendApproval")
    public void sendApproval(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendApproval triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String probuildProcessKey = String.valueOf(job.getProcessInstanceKey());
        vars.put("probuildProcessKey", probuildProcessKey);
        publishToCatchEvent("repairApproved", "repairApproved", vars);
        LOGGER.info("Repair approval sent | probuildProcessKey={}", probuildProcessKey);
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("probuildProcessKey", probuildProcessKey))
                .send().join();
    }

    // ─────────────────────────────────────────────────────────────────
    // FIXPRO LTD POOL
    // ─────────────────────────────────────────────────────────────────

    @JobWorker(type = "toolsForMaintenance")
    public void sendToolsForMaintenance(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendToolsForMaintenance triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String probuildProcessKey = String.valueOf(job.getProcessInstanceKey());
        vars.put("probuildProcessKey", probuildProcessKey);
        publishToStartEvent("toolsForMaintenance", vars);
        LOGGER.info("Tools sent for maintenance | probuildProcessKey={}", probuildProcessKey);
        client.newCompleteCommand(job.getKey())
                .variables(Map.of("probuildProcessKey", probuildProcessKey))
                .send().join();
    }

    @JobWorker(type = "sendRepairAuthorisation")
    public void sendRepairAuthorisation(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendRepairAuthorisation triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String probuildProcessKey = getVar(vars, "probuildProcessKey", "NOT_FOUND");
        Map<String, Object> payload = new HashMap<>(vars);
        publishToCatchEvent("repairAuthorisation", probuildProcessKey, payload);
        LOGGER.info("Repair authorisation sent | probuildProcessKey={}", probuildProcessKey);
        client.newCompleteCommand(job.getKey()).send().join();
    }

    @JobWorker(type = "sendDisapproval")
    public void sendDisapproval(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendDisapproval triggered");
        publishToCatchEvent("repairDisapproved", "repairDisapproved", Map.of("repairApproved", false));
        client.newCompleteCommand(job.getKey()).send().join();
    }

    @JobWorker(type = "sendToolsBack")
    public void sendToolsBack(final ActivatedJob job, final JobClient client) {
        LOGGER.info("sendToolsBack triggered");
        Map<String, Object> vars = job.getVariablesAsMap();
        String probuildProcessKey = getVar(vars, "probuildProcessKey", "NOT_FOUND");
        Map<String, Object> payload = new HashMap<>(vars);
        publishToCatchEvent("toolsReturned", probuildProcessKey, payload);
        LOGGER.info("Tools returned to ProBuild | probuildProcessKey={}", probuildProcessKey);
        client.newCompleteCommand(job.getKey()).send().join();
    }
}